# FitQuest Workout History Patch

Adds an editable Workout History panel to the existing FitQuest Vite project.

## Features
- View every saved workout/day and its exercises.
- See exercise count, strength sets, cardio minutes, and XP per day.
- Move an entire workout to a different date.
- Move one exercise to a different date.
- Automatically creates a destination adventure when needed.
- Keeps an empty source record visible so nothing disappears silently.
- Remove empty workout records explicitly.
- Export the current FitQuest localStorage save as a JSON backup.

## Install

1. Copy `src/history.js` and `src/history.css` into the repository's `src/` folder.
2. In `index.html`, directly after the existing FitQuest app script:

```html
<script type="module" src="/src/app.js"></script>
```

add:

```html
<script type="module" src="/src/history.js"></script>
```

3. Commit to `main`. Cloudflare should redeploy automatically.
4. Open FitQuest on the same Safari/iPhone where the existing save lives and refresh.

No localStorage key is changed. The history editor works against `fitquest-save-v1`.